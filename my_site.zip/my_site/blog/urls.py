from django.urls import path
from . import views


urlpatterns = [
    path("user/", views.UserView.as_view(), name='user-page'),
    path("", views.StartingPageView.as_view(), name="starting-page"),
    path("posts", views.AllPostsView.as_view(), name="posts-page"),
    path("posts/<slug:slug>", views.PostDetailView.as_view(), name="post-detail-page"),   #/posts/my-firs-post
    path("login/", views.LoginView.as_view(), name="login-page"),
    path("register/", views.RegisterView.as_view(), name="register-page"),
#    path("dashboard/", views.DashboardView.as_view(), name="dashboard-page"),
    path("logout/", views.logoutpage, name="logout"),
    path("readlater/", views.ReadLaterView.as_view(), name="readlater"),
]
